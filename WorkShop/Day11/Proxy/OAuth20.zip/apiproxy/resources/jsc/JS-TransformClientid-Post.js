var incoming_clientid = context.getVariable('request.content');
var indexOfClientId= incoming_clientid.indexOf('client_id=')+10;
var indexOfClientSecret= incoming_clientid.indexOf('client_secret=')+14;
var intermediate_clientid;
var outgoing_clientsecret;
var outgoing_clientid;
 if (indexOfClientId>0)
 {
    intermediate_clientid =  incoming_clientid.substring(indexOfClientId).substring(0,incoming_clientid.substring(indexOfClientId).indexOf('&'));
    outgoing_clientsecret = incoming_clientid.substring(indexOfClientSecret);
    var indexOfColon= intermediate_clientid.indexOf('%3A');
    if (indexOfColon>0)
    {
        outgoing_clientid = 
        intermediate_clientid.substring(0,indexOfColon)+'_'+intermediate_clientid.substring(indexOfColon+3);
    }
    else
    {
        outgoing_clientid = intermediate_clientid;
    }
 }
 context.setVariable('request.queryparam.client_id',outgoing_clientid)
 context.setVariable('request.queryparam.client_secret',outgoing_clientsecret)
