  var incoming_clientid = context.getVariable('request.queryparam.client_id');
 var index= incoming_clientid.indexOf(':');
 var outgoing_clientid;
 if (index>0)
 {
 outgoing_clientid = 
 incoming_clientid.substring(0,index)+'_'+incoming_clientid.substring(index+1);
 }
 else
 {
     outgoing_clientid = incoming_clientid;
 }
 context.setVariable('request.queryparam.client_id',outgoing_clientid)