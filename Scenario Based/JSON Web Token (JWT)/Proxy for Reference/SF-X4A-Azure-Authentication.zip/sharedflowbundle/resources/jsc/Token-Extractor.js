var auth = context.getVariable('request.header.Authorization');
if(auth && auth.startsWith('Bearer ')) { 
    var token = auth.substring(auth.indexOf(' ') + 1);
    context.setVariable("bearerToken",token);
}
else{
    context.setVariable("bearerToken",'');
}