var appName = context.getVariable("jwt.DecodeJWT.claim.appName");
apikey="APPVEP";
context.setVariable("apikey",apikey);