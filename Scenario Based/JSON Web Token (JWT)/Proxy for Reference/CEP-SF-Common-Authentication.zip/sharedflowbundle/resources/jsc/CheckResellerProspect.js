var resellerProspect = context.getVariable("jwt.DecodeJWT.claim.resellerProspect");
if (resellerProspect === true) {
    context.setVariable('isResellerProspect', true);
} else {
    context.setVariable('isResellerProspect', false);
}