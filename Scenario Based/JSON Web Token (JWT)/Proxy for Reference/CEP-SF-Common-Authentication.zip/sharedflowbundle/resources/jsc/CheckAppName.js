var appName = context.getVariable("jwt.DecodeJWT.claim.appName");
if(appName.indexOf("IMOnline"!=-1))
  	apikey="APPIMONLINE";
if(appName.indexOf("IMCEP"!=-1))
  	apikey="APPCEP";
if(appName.indexOf("IMX4CMOBANDROID"!=-1))
  	apikey="APPIMX4CMOBANDROID";
if(appName.indexOf("IMX4CMOBIOS"!=-1))
  	apikey="APPIMX4CMOBIOS";   	
else apikey="ERROR";
context.setVariable("apikey",apikey);